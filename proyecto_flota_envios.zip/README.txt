Proyecto Flota de envíos - Java

Estructura:
src/
  envios/
    modelo/  (Vehiculo, Moto, Camion, Bicicleta, Asegurable, Bodega, Flota)
    app/     (PruebaHerencia y Main)

Compilar desde la carpeta del proyecto:
  javac -d out src/envios/modelo/*.java src/envios/app/*.java

Ejecutar:
  java -cp out envios.app.PruebaHerencia
  java -cp out envios.app.Main

El proyecto incluye las etapas 1 a 4 y los retos implementables de la Parte B.
