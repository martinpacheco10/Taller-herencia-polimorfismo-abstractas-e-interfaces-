package envios.app;

import envios.modelo.*;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        Moto m1 = new Moto("MZL12A", 20, 150);
        Camion c1 = new Camion("WFT345", 8000, 2);
        Moto m2 = new Moto("KJH78B", 25, 200);

        Flota flota = new Flota("Envíos Caldas");
        flota.agregar(m1);
        flota.agregar(c1);
        flota.agregar(m2);
        System.out.println(flota.agregar(m1));
        flota.mostrar();
        System.out.println(flota.cantidadCamiones());

        System.out.println(m1.costoEnvio(12));
        System.out.println(c1.costoEnvio(12));

        Bicicleta b1 = new Bicicleta("BIC001", 10);
        flota.agregar(b1);
        flota.mostrar();
        System.out.println(flota.masEconomico(8).getPlaca());
        System.out.println(flota.masEconomico(22).getPlaca());
        System.out.println(flota.masEconomico(500).getPlaca());
        System.out.println(flota.masEconomico(9000));

        System.out.println(m1.valorSeguro());
        System.out.println(c1.valorSeguro());
        System.out.println(flota.totalSeguros());

        ArrayList<Asegurable> asegurables = new ArrayList<>();
        asegurables.add(c1);
        asegurables.add(new Bodega("Bodega Chipre", 300));
        double suma = 0;
        for (Asegurable asegurable : asegurables) {
            double seguro = asegurable.valorSeguro();
            System.out.println(seguro);
            suma += seguro;
        }
        System.out.println(suma);

        System.out.println(c1.costoEnvio(10, true));
        System.out.println(c1.costoEnvio(10, false));

        Vehiculo w = c1;
        if (w instanceof Camion) {
            System.out.println(((Camion) w).getEjes());
        }

        Vehiculo v = new Moto("AAA11A", 20, 100);
        System.out.println(v.describir());
        System.out.println(v.costoEnvio(10));
        System.out.println(v instanceof Asegurable);
        System.out.println(v instanceof Camion);
        Asegurable a = new Bodega("Bodega Norte", 50);
        System.out.println(a.valorSeguro());
    }
}
